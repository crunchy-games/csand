CSAND
*** copyright <c> Dominic ("Dom") Kolp ***
Pronounced "sand"

To load a specific save, drag and drop the save
into 'data/to-load'. There can only be one save
in the to-load folder.

*** keyboard commands ***
1      | sand
2      | wall
3      | water
4      | acid
5      | wood
6      | fire
e      | eraser tool
s      | spray tool
p      | pencil tool
r      | restart
esc    | pause
ctrl+s | save game
ctrl+l | load most recent save

*** mouse commands ***
ms1    | use current tool
ms2    | use eraser tool

*** other ***
https://github.com/stupidlilgoober/csand
https://discord.gg/9x2fgGxaV7
read 'license'
read 'contributing'
